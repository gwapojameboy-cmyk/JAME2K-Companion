import tkinter as tk
from tkinter import ttk, filedialog, messagebox, colorchooser
from pathlib import Path
import json

from .designer import DesignCanvas, draw_scoreboard, draw_shot_meter

APP_BG = "#090909"
PANEL = "#151515"
RED = "#e32636"
TEXT = "#f4f4f5"
MUTED = "#a1a1aa"


class Jame2KApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("JAME2K Companion")
        self.geometry("1120x720")
        self.minsize(900, 620)
        self.configure(bg=APP_BG)
        self.config_data = {
            "home_name": "HOME", "away_name": "AWAY",
            "home_score": "88", "away_score": "82",
            "period": "4TH", "clock": "02:45",
            "primary": "#e32636", "secondary": "#ffffff",
            "meter_color": "#e32636", "meter_width": 22,
            "meter_height": 260, "meter_style": "Vertical"
        }
        self._style()
        self._build_shell()
        self.show_dashboard()

    def _style(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TCombobox", fieldbackground="#222222",
                        background="#222222", foreground=TEXT)
        style.configure("TEntry", fieldbackground="#222222",
                        foreground=TEXT, insertcolor=TEXT)
        style.configure("TButton", padding=8)

    def _build_shell(self):
        header = tk.Frame(self, bg="#101010", height=72)
        header.pack(fill="x")
        tk.Label(header, text="JAME2K", fg=RED, bg="#101010",
                 font=("Arial", 22, "bold")).pack(side="left", padx=(22, 8), pady=15)
        tk.Label(header, text="NBA 2K20 COMPANION", fg=TEXT, bg="#101010",
                 font=("Arial", 10, "bold")).pack(side="left", pady=20)
        tk.Label(header, text="DESKTOP EDITION  •  v1.0", fg=MUTED, bg="#101010",
                 font=("Arial", 9)).pack(side="right", padx=22)

        body = tk.Frame(self, bg=APP_BG)
        body.pack(fill="both", expand=True)
        nav = tk.Frame(body, bg="#101010", width=205)
        nav.pack(side="left", fill="y")
        nav.pack_propagate(False)
        tk.Label(nav, text="WORKSPACE", bg="#101010", fg=MUTED,
                 font=("Arial", 9, "bold")).pack(anchor="w", padx=18, pady=(24, 12))
        for label, callback in [
            ("Dashboard", self.show_dashboard),
            ("Scoreboard Designer", self.show_scoreboard),
            ("Shot Meter Designer", self.show_meter),
            ("Project Settings", self.show_settings),
        ]:
            tk.Button(nav, text=label, command=callback, anchor="w",
                      bg="#1b1b1b", fg=TEXT, activebackground="#351016",
                      activeforeground=TEXT, relief="flat", bd=0,
                      font=("Arial", 10), padx=14, pady=12).pack(fill="x", padx=10, pady=4)

        self.content = tk.Frame(body, bg=APP_BG)
        self.content.pack(side="left", fill="both", expand=True, padx=24, pady=22)

    def clear(self):
        for widget in self.content.winfo_children():
            widget.destroy()

    def title(self, heading, subtitle):
        tk.Label(self.content, text=heading, bg=APP_BG, fg=TEXT,
                 font=("Arial", 21, "bold")).pack(anchor="w")
        tk.Label(self.content, text=subtitle, bg=APP_BG, fg=MUTED,
                 font=("Arial", 10)).pack(anchor="w", pady=(4, 18))

    def card(self, parent, title, detail):
        frame = tk.Frame(parent, bg=PANEL, padx=18, pady=16)
        tk.Label(frame, text=title, bg=PANEL, fg=RED,
                 font=("Arial", 12, "bold")).pack(anchor="w")
        tk.Label(frame, text=detail, bg=PANEL, fg=TEXT,
                 font=("Arial", 10), justify="left").pack(anchor="w", pady=(8, 0))
        return frame

    def show_dashboard(self):
        self.clear()
        self.title("Dashboard", "Your creative workspace for NBA 2K20 companion designs.")
        cards = tk.Frame(self.content, bg=APP_BG)
        cards.pack(fill="x")
        for title, detail in [
            ("SCOREBOARD", "Create a custom scoreboard\nand export a PNG preview."),
            ("SHOT METER", "Adjust colors, dimensions,\nand visual style."),
            ("PROJECT FILES", "Save and reopen your\nJAME2K configuration."),
        ]:
            self.card(cards, title, detail).pack(side="left", fill="both",
                                                  expand=True, padx=(0, 12))
        note = tk.Frame(self.content, bg="#191919", padx=18, pady=18)
        note.pack(fill="x", pady=22)
        tk.Label(note, text="QUICK START", bg="#191919", fg=TEXT,
                 font=("Arial", 13, "bold")).pack(anchor="w")
        tk.Label(note, text="Choose Scoreboard Designer or Shot Meter Designer from the left menu. "
                 "Use Export PNG to save your original design preview.",
                 bg="#191919", fg=MUTED, wraplength=700, justify="left").pack(anchor="w", pady=8)
        tk.Label(self.content, text="Standalone design utility • No game files are changed",
                 bg=APP_BG, fg=MUTED, font=("Arial", 9)).pack(anchor="w")

    def _field(self, parent, label, key, width=18):
        box = tk.Frame(parent, bg=PANEL)
        box.pack(fill="x", pady=5)
        tk.Label(box, text=label, bg=PANEL, fg=MUTED, width=16,
                 anchor="w").pack(side="left")
        entry = tk.Entry(box, width=width, bg="#222222", fg=TEXT,
                         insertbackground=TEXT, relief="flat")
        entry.insert(0, str(self.config_data[key]))
        entry.pack(side="left", ipady=7, padx=5)
        return entry

    def _preview_area(self, parent):
        area = tk.Frame(parent, bg="#080808", highlightbackground="#333333",
                        highlightthickness=1)
        area.pack(side="right", fill="both", expand=True, padx=(18, 0))
        canvas = tk.Canvas(area, bg="#080808", highlightthickness=0)
        canvas.pack(fill="both", expand=True, padx=12, pady=12)
        return canvas

    def show_scoreboard(self):
        self.clear()
        self.title("Scoreboard Designer", "Edit team labels, score, period, clock, and colors.")
        left = tk.Frame(self.content, bg=PANEL, padx=14, pady=14)
        left.pack(side="left", fill="y")
        entries = {}
        for label, key in [
            ("Home team", "home_name"), ("Away team", "away_name"),
            ("Home score", "home_score"), ("Away score", "away_score"),
            ("Period", "period"), ("Game clock", "clock")
        ]:
            entries[key] = self._field(left, label, key)

        color_row = tk.Frame(left, bg=PANEL)
        color_row.pack(fill="x", pady=10)
        tk.Button(color_row, text="Choose accent color", command=self.choose_primary,
                  bg="#292929", fg=TEXT, relief="flat").pack(fill="x")
        canvas = self._preview_area(self.content)

        def update(*_):
            for key, entry in entries.items():
                self.config_data[key] = entry.get().strip()
            draw_scoreboard(canvas, self.config_data)

        tk.Button(left, text="UPDATE PREVIEW", command=update, bg=RED, fg="white",
                  activebackground="#b91c2b", relief="flat").pack(fill="x", pady=(8, 4))
        tk.Button(left, text="EXPORT PNG", command=lambda: self.export(canvas),
                  bg="#292929", fg=TEXT, relief="flat").pack(fill="x", pady=4)
        tk.Button(left, text="SAVE PROJECT", command=self.save_project,
                  bg="#292929", fg=TEXT, relief="flat").pack(fill="x", pady=4)
        canvas.bind("<Configure>", lambda e: draw_scoreboard(canvas, self.config_data))
        update()

    def show_meter(self):
        self.clear()
        self.title("Shot Meter Designer", "Create a visual shot-meter concept and export its preview.")
        left = tk.Frame(self.content, bg=PANEL, padx=16, pady=16)
        left.pack(side="left", fill="y")
        canvas = self._preview_area(self.content)
        self.config_data["meter_width"] = int(self.config_data["meter_width"])
        self.config_data["meter_height"] = int(self.config_data["meter_height"])

        tk.Label(left, text="Meter color", bg=PANEL, fg=MUTED).pack(anchor="w")
        tk.Button(left, text="Choose color", command=self.choose_meter,
                  bg="#292929", fg=TEXT, relief="flat").pack(fill="x", pady=5)

        tk.Label(left, text="Meter width", bg=PANEL, fg=MUTED).pack(anchor="w", pady=(12, 2))
        width = tk.Scale(left, from_=8, to=50, orient="horizontal",
                         bg=PANEL, fg=TEXT, troughcolor="#333333",
                         highlightthickness=0, command=lambda v: self._set_meter("meter_width", v, canvas))
        width.set(self.config_data["meter_width"])
        width.pack(fill="x")

        tk.Label(left, text="Meter height", bg=PANEL, fg=MUTED).pack(anchor="w", pady=(12, 2))
        height = tk.Scale(left, from_=120, to=420, orient="horizontal",
                          bg=PANEL, fg=TEXT, troughcolor="#333333",
                          highlightthickness=0, command=lambda v: self._set_meter("meter_height", v, canvas))
        height.set(self.config_data["meter_height"])
        height.pack(fill="x")

        tk.Button(left, text="EXPORT PNG", command=lambda: self.export(canvas),
                  bg=RED, fg="white", relief="flat").pack(fill="x", pady=(18, 5))
        tk.Button(left, text="SAVE PROJECT", command=self.save_project,
                  bg="#292929", fg=TEXT, relief="flat").pack(fill="x")
        canvas.bind("<Configure>", lambda e: draw_shot_meter(canvas, self.config_data))
        draw_shot_meter(canvas, self.config_data)

    def _set_meter(self, key, value, canvas):
        self.config_data[key] = int(float(value))
        draw_shot_meter(canvas, self.config_data)

    def choose_primary(self):
        color = colorchooser.askcolor(color=self.config_data["primary"], parent=self)[1]
        if color:
            self.config_data["primary"] = color
            self.show_scoreboard()

    def choose_meter(self):
        color = colorchooser.askcolor(color=self.config_data["meter_color"], parent=self)[1]
        if color:
            self.config_data["meter_color"] = color
            self.show_meter()

    def export(self, canvas):
        path = filedialog.asksaveasfilename(
            defaultextension=".png", filetypes=[("PNG image", "*.png")],
            initialfile="jame2k_design.png")
        if not path:
            return
        try:
            from PIL import Image
            from PIL import ImageGrab
            # Render the canvas as PostScript, then convert with Pillow.
            ps = canvas.postscript(colormode="color")
            import io
            img = Image.open(io.BytesIO(ps.encode("utf-8")))
            img.save(path, "PNG")
            messagebox.showinfo("Export complete", f"Saved design to:\n{path}")
        except Exception as exc:
            messagebox.showerror("Export failed",
                "PNG export needs Pillow and a working Tk PostScript renderer.\n\n"
                f"Details: {exc}")

    def save_project(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".json", filetypes=[("JAME2K project", "*.json")],
            initialfile="jame2k_project.json")
        if not path:
            return
        try:
            Path(path).write_text(json.dumps(self.config_data, indent=2), encoding="utf-8")
            messagebox.showinfo("Saved", f"Project saved to:\n{path}")
        except OSError as exc:
            messagebox.showerror("Save failed", str(exc))

    def show_settings(self):
        self.clear()
        self.title("Project Settings", "Save, load, and manage your local design configuration.")
        panel = tk.Frame(self.content, bg=PANEL, padx=18, pady=18)
        panel.pack(anchor="nw", fill="x")
        tk.Label(panel, text="PROJECT CONFIGURATION", bg=PANEL, fg=RED,
                 font=("Arial", 12, "bold")).pack(anchor="w")
        tk.Label(panel, text="Configuration files use JSON and are stored wherever you choose.",
                 bg=PANEL, fg=TEXT, wraplength=650).pack(anchor="w", pady=10)
        tk.Button(panel, text="SAVE CURRENT PROJECT", command=self.save_project,
                  bg=RED, fg="white", relief="flat").pack(anchor="w", pady=4)
        tk.Button(panel, text="LOAD PROJECT", command=self.load_project,
                  bg="#292929", fg=TEXT, relief="flat").pack(anchor="w", pady=4)

    def load_project(self):
        path = filedialog.askopenfilename(filetypes=[("JAME2K project", "*.json")])
        if not path:
            return
        try:
            data = json.loads(Path(path).read_text(encoding="utf-8"))
            allowed = set(self.config_data)
            if not isinstance(data, dict) or not set(data).issubset(allowed):
                raise ValueError("This file is not a valid JAME2K project.")
            self.config_data.update(data)
            messagebox.showinfo("Loaded", "Project configuration loaded.")
            self.show_dashboard()
        except (OSError, json.JSONDecodeError, ValueError) as exc:
            messagebox.showerror("Load failed", str(exc))
