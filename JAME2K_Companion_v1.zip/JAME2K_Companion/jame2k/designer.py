def draw_scoreboard(canvas, data):
    canvas.delete("all")
    w = max(canvas.winfo_width(), 400)
    h = max(canvas.winfo_height(), 260)
    accent = data.get("primary", "#e32636")
    x0, y0 = w * .08, h * .35
    x1, y1 = w * .92, h * .68
    canvas.create_rectangle(x0, y0, x1, y1, fill="#111111",
                            outline=accent, width=3)
    canvas.create_rectangle(x0, y0, x1, y0 + 9, fill=accent, outline=accent)
    mid = w / 2
    canvas.create_line(mid, y0 + 10, mid, y1, fill="#444444", width=2)
    font_big = ("Arial", max(22, int(h * .12)), "bold")
    font_small = ("Arial", max(10, int(h * .035)), "bold")
    canvas.create_text(w * .28, h * .43, text=data.get("home_name", "HOME"),
                       fill="white", font=font_small)
    canvas.create_text(w * .28, h * .56, text=data.get("home_score", "88"),
                       fill="white", font=font_big)
    canvas.create_text(w * .72, h * .43, text=data.get("away_name", "AWAY"),
                       fill="white", font=font_small)
    canvas.create_text(w * .72, h * .56, text=data.get("away_score", "82"),
                       fill="white", font=font_big)
    canvas.create_text(mid, h * .77,
                       text=f'{data.get("period", "4TH")}  |  {data.get("clock", "02:45")}',
                       fill=accent, font=font_small)
    canvas.create_text(w / 2, h * .18, text="JAME2K SCOREBOARD CONCEPT",
                       fill="#bbbbbb", font=("Arial", 11, "bold"))


def draw_shot_meter(canvas, data):
    canvas.delete("all")
    w = max(canvas.winfo_width(), 400)
    h = max(canvas.winfo_height(), 300)
    meter_w = int(data.get("meter_width", 22))
    meter_h = int(data.get("meter_height", 260))
    color = data.get("meter_color", "#e32636")
    x = w / 2
    top = max(35, (h - meter_h) / 2)
    bottom = min(h - 35, top + meter_h)
    canvas.create_text(x, 28, text="JAME2K SHOT METER CONCEPT",
                       fill="#bbbbbb", font=("Arial", 11, "bold"))
    canvas.create_rectangle(x - meter_w/2, top, x + meter_w/2, bottom,
                            fill="#242424", outline="#777777", width=2)
    # Original visual target marker; decorative only.
    target_y = top + (bottom - top) * .28
    canvas.create_rectangle(x - meter_w/2 - 8, target_y - 5,
                            x + meter_w/2 + 8, target_y + 5,
                            fill=color, outline=color)
    canvas.create_text(x + meter_w + 35, target_y,
                       text="RELEASE", fill=color, font=("Arial", 10, "bold"))
    canvas.create_text(x, bottom + 24, text="CUSTOM PREVIEW",
                       fill="#aaaaaa", font=("Arial", 9))
