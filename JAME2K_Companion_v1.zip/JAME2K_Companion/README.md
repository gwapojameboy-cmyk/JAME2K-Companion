# JAME2K Companion

A standalone Python desktop utility for creating original NBA 2K20-inspired scoreboard and shot-meter concept designs.

## Features
- Dark desktop interface built with Tkinter
- Editable scoreboard labels, scores, period, and clock
- Editable shot-meter color, width, and height
- Save/load project configuration as JSON
- Export canvas previews as PNG using Pillow

## Requirements
- Python 3.10 or newer
- Tkinter (included with most standard Python installations)
- Pillow

## Setup

### Windows
```bash
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

### macOS / Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python main.py
```

## Notes
This is a standalone companion/design utility. It creates original visual previews and JSON project files. It does not read, patch, or modify NBA 2K20 game files.
