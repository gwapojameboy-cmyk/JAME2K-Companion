from jame2k.app import Jame2KApp

if __name__ == "__main__":
    Jame2KApp().mainloop()
